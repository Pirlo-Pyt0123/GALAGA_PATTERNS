// Fill out your copyright notice in the Description page of Project Settings.


#include "PO_In_Sujeto_Identificado.h"

// Add default functionality here for any IPO_In_Sujeto_Identificado functions that are not pure virtual.
