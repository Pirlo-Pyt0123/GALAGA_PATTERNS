// Fill out your copyright notice in the Description page of Project Settings.


#include "Proyectil_Misil.h"
#include "Components/StaticMeshComponent.h"
#include "Components/CapsuleComponent.h"
#include "Particles/ParticleSystem.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Sharing_PatternsPawn.h"

AProyectil_Misil::AProyectil_Misil()
{
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/Mallas_Nave_Enemiga/VARIOS_A/Missile.Missile'"));
	if (MeshAsset.Succeeded())
	{
		Projectil_Mesh->SetStaticMesh(MeshAsset.Object);

		//// Modificar la escala del componente de malla
		//FVector NewScale(-1.0f, -1.0f, -1.0f); // Escala modificada
		//Projectil_Mesh->SetWorldScale3D(NewScale);
	}


	// En el constructor de AProyectil_Bomba_Pa, aseg�rate de incluir:
	Projectil_Movement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement"));
	Projectil_Movement->UpdatedComponent = RootComponent; // Asegurarse de que el componente de movimiento se actualiza correctamente.

	// Estableciendo el tiempo de vida inicial del proyectil
	InitialLifeSpan = 5.f;

	// Da�o predeterminado del proyectil
	DanioProvocado = 0.f;
	//Configurando el proyectil para que genere eventos de colision
	Projectil_Collision->SetCapsuleHalfHeight(160.0f);
	Projectil_Collision->SetCapsuleRadius(160.0f);


}

void AProyectil_Misil::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AProyectil_Misil::BeginPlay()
{
	Super::BeginPlay();
}



void AProyectil_Misil::NotifyActorBeginOverlap(AActor* OtherActor)
{
	ASharing_PatternsPawn* Player = Cast<ASharing_PatternsPawn>(OtherActor);
	if (Player)
	{
		DestroyPROYECTIL();
	}
}

void AProyectil_Misil::DestroyPROYECTIL()
{
	// Reproducir el sonido del proyectil
	UGameplayStatics::PlaySoundAtLocation(this, Projectil_Sound, GetActorLocation());

	// Crear una explosi�n de part�culas
	UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), Explosion_Particles, GetActorLocation());

	// Destruir el proyectil
	Destroy();
}
