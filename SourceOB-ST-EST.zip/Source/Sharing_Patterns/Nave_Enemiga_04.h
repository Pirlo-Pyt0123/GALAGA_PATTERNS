// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Nave_Enemiga_P.h"
#include "Nave_Enemiga_04.generated.h"

UCLASS()
class SHARING_PATTERNS_API ANave_Enemiga_04 : public ANave_Enemiga_P
{
	GENERATED_BODY()
//
//public:
//
//	// Sets default values for this actor's properties
//	ANave_Enemiga_04();
//
//
//public:
//
//	virtual void NotifyActorBeginOverlap(AActor* OtherActor) override;
//
//	virtual void Componente_Destruccion() override;
//
//	virtual void Recibir_Danio(float Danio) override;
//
//public:
//
//	virtual void Tick(float DeltaTime) override;
//
//	virtual void BeginPlay() override;
//
//
//	
};
